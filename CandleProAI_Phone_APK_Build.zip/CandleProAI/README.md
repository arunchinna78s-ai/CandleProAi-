# CandlePro AI — Android starter (signals only)

## Included
- Native Android / Kotlin / Jetpack Compose starter.
- Binance public **Spot** market data only (no API key).
- 5-minute OHLC candles for BTCUSDT, ETHUSDT, BNBUSDT, SOLUSDT and XRPUSDT.
- Basic candle plot, closed-candle EMA(9)/EMA(21) + RSI(14) signal filter.
- WAIT / BUY / SELL output and illustrative ATR-based stop/target references.
- $10 reference capital and 1% ($0.10) maximum planned risk budget.
- No exchange login, no trading permissions, no order placement, no leverage.

## Data source
Uses Binance's public market-data endpoint:
`https://data-api.binance.vision/api/v3/klines?symbol=BTCUSDT&interval=5m&limit=120`

Binance documents this as a public market-data-only endpoint that does not require an API key. The app refreshes every 15 seconds and excludes the currently forming candle from signal calculations.

## Build
1. Open this folder in Android Studio (Giraffe or newer; JDK 17).
2. Let Gradle sync.
3. Connect an Android phone with USB debugging enabled, or use an emulator.
4. Press Run, or select Build > Build APK(s).
5. Debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
- This is a first implementation, not a validated profitable strategy.
- Signals are technical rule outputs, not predictions or recommendations.
- A 1% risk budget is not guaranteed by the app. Stop gaps, slippage, fees, spread, minimum order sizes and execution can cause larger losses.
- A $0.10 risk amount may be impractical on some symbols after exchange minimum-notional and fee requirements.
- The displayed stop and target are reference levels only; the app does not place orders or monitor an actual position.
- It currently uses Binance Spot market data. It does not access futures data or GuruTrade7.
- Do not add Binance API keys to this app. Any future private trading integration would require a separate security review and explicit opt-in.

## Next development steps
- Add a full chart library and selectable USDT pair search.
- Add push notifications and signal history.
- Backtest with fees/slippage and paper-trade before relying on alerts.
- Improve risk sizing by checking lot size, minimum notional, spread and actual stop distance.


## Requested live automation policy (configured, execution locked)

The selected policy is now represented in `AutomationPolicy.kt`:
- Requested mode: LIVE
- Venue/product: Binance Spot (not Futures)
- Timeframe: 5m, closed candles only
- Starting capital reference: USD 10
- Planned per-trade risk budget: USD 0.10 (1%)
- Leverage: 1x
- Mandatory stop-loss
- Notifications preference: enabled
- Maximum one open position
- Daily realized-loss circuit breaker: USD 0.20 (2% of starting capital)
- Maximum three trades per day
- 60-minute cooldown after two consecutive losses
- Reject an order if fees/slippage consume the risk budget or the exchange minimum notional is too large.

**Live orders are NOT enabled in this source project.** The app has no private-account connection, notification implementation, secure execution backend, order/stop reconciliation, or recovery service. `SecureExecutionService` is only an interface contract, not a functioning Binance connector. Do not treat the LIVE selection as permission to send orders.

### Required before any real-money deployment
1. Build and deploy a backend execution service; do not put API secrets in the Android app or send them in chat.
2. Store credentials in a server-side secret manager. Use a dedicated Binance API key with withdrawals disabled, IP allowlisting, and only the minimum permissions required. Binance explicitly warns that API key and secret are sensitive; signed private endpoints require authentication and signatures. See official docs: https://developers.binance.com/en/docs/products/spot/rest-api
3. Validate the full workflow on Binance Spot Testnet first: order sizing, exchange symbol filters, fees, partial fills, stop placement, rejected orders, disconnects, duplicate signals and restart recovery. Spot Testnet docs: https://developers.binance.com/en/docs/products/spot/testnet/rest-api
4. Enforce a server-side kill switch, idempotent client order IDs, balance checks, daily loss limits and reconciliation against Binance order/position state.
5. Only then consider enabling a separately reviewed live execution adapter with explicit user confirmation.

For this USD 10 account, the $0.10 planned risk can be below exchange minimum order sizes after stop-distance and fee calculations. In that case the correct action is to skip the trade, not increase risk.


## Phone-only APK build using GitHub Actions
This project includes `.github/workflows/android-apk.yml`. From a phone:
1. Create/sign in to a GitHub account and create a new repository.
2. Upload the contents of this project ZIP into the repository root (not the ZIP itself), ensuring `.github/workflows/android-apk.yml` is included.
3. Open the repository's Actions tab, select **Build CandlePro AI APK**, and tap **Run workflow** (or wait for the push-triggered build).
4. When the run finishes successfully, open the run, scroll to **Artifacts**, and download `CandleProAI-debug-apk`.
5. Extract the artifact ZIP to get `app-debug.apk`, then tap the APK to install. If Android asks, allow Chrome or your file manager to install unknown apps for this one installation, then turn that permission off again.

A successful workflow produces a debug APK. GitHub account/repository setup and upload are still required. The app remains a signal tool; this workflow does not enable real-money order execution.
