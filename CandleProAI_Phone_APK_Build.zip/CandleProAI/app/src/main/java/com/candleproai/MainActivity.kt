package com.candleproai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.URL
import kotlin.math.max
import kotlin.math.min

private val Bg = Color(0xFF0B1220)
private val Panel = Color(0xFF151F30)
private val Muted = Color(0xFF9AA8BA)
private val Green = Color(0xFF2BD99A)
private val Red = Color(0xFFFF647C)
private val Accent = Color(0xFF62A8FF)

data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)
data class Signal(val side: String, val reason: String, val entry: Double?, val stop: Double?, val target: Double?, val riskUsd: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CandleProApp() }
    }
}

@Composable
fun CandleProApp() {
    var symbol by remember { mutableStateOf("BTCUSDT") }
    var candles by remember { mutableStateOf<List<Candle>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var refreshed by remember { mutableLongStateOf(0L) }

    LaunchedEffect(symbol) {
        while (true) {
            try {
                val data = withContext(Dispatchers.IO) { fetchCandles(symbol) }
                candles = data
                error = null
                refreshed = System.currentTimeMillis()
            } catch (e: Exception) {
                error = "Unable to load Binance data. Check internet and retry."
            }
            loading = false
            delay(15_000)
        }
    }

    val signal = remember(candles) { makeSignal(candles) }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Accent)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("CandlePro AI", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("BINANCE • SPOT • 5 MIN", color = Muted, fontSize = 11.sp)
                }
                Text("SIGNALS ONLY", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT").forEach {
                    FilterChip(selected = symbol == it, onClick = { symbol = it }, label = { Text(it) })
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(symbol, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("5m candles", color = Muted, fontSize = 12.sp)
                    }
                    val last = candles.lastOrNull()
                    Text(last?.let { "$" + "%,.4f".format(it.close) } ?: if (loading) "Loading…" else "—",
                        color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text(if (refreshed > 0) "Updated ${java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date(refreshed))}" else "Waiting for data", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    CandleChart(candles.takeLast(48), Modifier.fillMaxWidth().height(150.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("CURRENT SIGNAL", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(signal.side, color = when(signal.side) { "BUY" -> Green; "SELL" -> Red; else -> Color.White }, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text(signal.reason, color = Muted, fontSize = 13.sp)
                    if (signal.entry != null) {
                        Spacer(Modifier.height(12.dp))
                        InfoLine("Entry reference", signal.entry)
                        InfoLine("Stop-loss reference", signal.stop!!)
                        InfoLine("Take-profit reference (2R)", signal.target!!)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Risk budget: $%.2f max (1%% of $10)".format(signal.riskUsd), color = Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("LOW-RISK GUARDRAILS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Bullet("Closed candles only; no intrabar signals")
                    Bullet("Max planned loss per idea: $0.10")
                    Bullet("No leverage, no auto-orders, no API keys")
                    Bullet("WAIT if trend, momentum or volatility filters disagree")
                    Bullet("Avoid trading if stop distance or fees make the setup impractical")
                }
            }
            Spacer(Modifier.height(8.dp))
            if (error != null) Text(error!!, color = Red, fontSize = 12.sp)
            Text("Educational signal tool, not financial advice. Signals are not guaranteed; verify fees, liquidity and risk before trading.", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable fun InfoLine(label: String, value: Double) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 12.sp)
        Text("%.6f".format(value), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
@Composable fun Bullet(s: String) {
    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
        Text("•", color = Green, modifier = Modifier.padding(end = 8.dp))
        Text(s, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun CandleChart(data: List<Candle>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (data.isEmpty()) return@Canvas
        val lo = data.minOf { it.low }; val hi = data.maxOf { it.high }
        val range = (hi - lo).takeIf { it > 0 } ?: 1.0
        val step = size.width / data.size
        data.forEachIndexed { i, c ->
            val x = step * (i + 0.5f)
            fun y(v: Double) = size.height - (((v - lo) / range).toFloat() * size.height)
            val color = if (c.close >= c.open) Green else Red
            drawLine(color, Offset(x, y(c.high)), Offset(x, y(c.low)), strokeWidth = 2f)
            val top = min(y(c.open), y(c.close)); val bottom = max(y(c.open), y(c.close))
            drawRect(color, topLeft = Offset(x - step * .28f, top), size = androidx.compose.ui.geometry.Size(step * .56f, max(2f, bottom - top)))
        }
    }
}

private fun fetchCandles(symbol: String): List<Candle> {
    val url = URL("https://data-api.binance.vision/api/v3/klines?symbol=$symbol&interval=5m&limit=120")
    val text = url.openConnection().apply { connectTimeout = 8000; readTimeout = 8000 }.getInputStream().bufferedReader().use { it.readText() }
    val arr = JSONArray(text)
    return (0 until arr.length()).map { i ->
        val row = arr.getJSONArray(i)
        Candle(row.getLong(0), row.getString(1).toDouble(), row.getString(2).toDouble(),
            row.getString(3).toDouble(), row.getString(4).toDouble(), row.getString(5).toDouble())
    }
}

private fun ema(values: List<Double>, period: Int): List<Double> {
    if (values.isEmpty()) return emptyList()
    val k = 2.0 / (period + 1)
    val out = mutableListOf<Double>()
    var e = values.take(period).average()
    for (i in values.indices) {
        if (i < period - 1) out.add(Double.NaN)
        else if (i == period - 1) out.add(e)
        else { e = values[i] * k + e * (1 - k); out.add(e) }
    }
    return out
}
private fun rsi(values: List<Double>, period: Int = 14): Double {
    if (values.size <= period) return 50.0
    var gains = 0.0; var losses = 0.0
    for (i in values.size - period until values.size) {
        val d = values[i] - values[i - 1]
        if (d > 0) gains += d else losses -= d
    }
    if (losses == 0.0) return 100.0
    return 100.0 - 100.0 / (1 + gains / losses)
}
private fun atr(data: List<Candle>, period: Int = 14): Double {
    if (data.size < period + 1) return 0.0
    val trs = (data.size - period until data.size).map { i ->
        max(data[i].high - data[i].low, max(kotlin.math.abs(data[i].high - data[i-1].close), kotlin.math.abs(data[i].low - data[i-1].close)))
    }
    return trs.average()
}
private fun makeSignal(all: List<Candle>): Signal {
    val risk = 0.10
    if (all.size < 60) return Signal("WAIT", "Collecting enough 5-minute candles for confirmation.", null, null, null, risk)
    // Binance returns the currently forming candle last. Exclude it to avoid repainting.
    val data = all.dropLast(1)
    val closes = data.map { it.close }
    val fast = ema(closes, 9); val slow = ema(closes, 21)
    val r = rsi(closes)
    val a = atr(data)
    val last = data.last()
    val prev = data[data.lastIndex - 1]
    if (a <= 0 || fast.last().isNaN() || slow.last().isNaN()) return Signal("WAIT", "Insufficient volatility data.", null, null, null, risk)
    val longTrend = fast.last() > slow.last() && last.close > fast.last()
    val shortTrend = fast.last() < slow.last() && last.close < fast.last()
    val momentumUp = last.close > prev.close && r in 52.0..68.0
    val momentumDown = last.close < prev.close && r in 32.0..48.0
    val stopDist = 1.5 * a
    val entry = last.close
    return when {
        longTrend && momentumUp -> Signal("BUY", "EMA 9 above EMA 21; RSI %.1f confirms bullish momentum.".format(r), entry, entry-stopDist, entry+2*stopDist, risk)
        shortTrend && momentumDown -> Signal("SELL", "EMA 9 below EMA 21; RSI %.1f confirms bearish momentum.".format(r), entry, entry+stopDist, entry-2*stopDist, risk)
        else -> Signal("WAIT", "No fully confirmed setup. RSI %.1f; wait for a closed-candle alignment.".format(r), null, null, null, risk)
    }
}
