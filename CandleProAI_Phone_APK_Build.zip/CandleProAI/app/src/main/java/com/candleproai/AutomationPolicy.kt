package com.candleproai

/**
 * User-selected automation policy.
 *
 * LIVE is a requested mode only. This starter intentionally has no live order
 * adapter. A separately hosted, audited execution service must enforce this
 * policy before any real order can be submitted.
 */
data class AutomationPolicy(
    val requestedMode: TradingMode = TradingMode.LIVE,
    val exchange: String = "BINANCE",
    val market: String = "SPOT",
    val timeframe: String = "5m",
    val startingCapitalUsd: Double = 10.0,
    val riskFraction: Double = 0.01,
    val leverage: Int = 1,
    val mandatoryStopLoss: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val maxOpenPositions: Int = 1,
    val maxDailyLossFraction: Double = 0.02,
    val maxTradesPerDay: Int = 3,
    val consecutiveLossLimit: Int = 2,
    val cooldownMinutesAfterLossLimit: Int = 60
) {
    val maxRiskUsd: Double get() = startingCapitalUsd * riskFraction
    val maxDailyLossUsd: Double get() = startingCapitalUsd * maxDailyLossFraction
}

enum class TradingMode { SIGNALS, PAPER, LIVE }

data class TradePreflight(
    val signalConfirmed: Boolean,
    val candleClosed: Boolean,
    val stopLossPrice: Double?,
    val entryPrice: Double,
    val estimatedFeesUsd: Double,
    val estimatedSlippageUsd: Double,
    val dailyRealizedLossUsd: Double,
    val tradesToday: Int,
    val consecutiveLosses: Int,
    val openPositions: Int,
    val exchangeMinNotionalUsd: Double
)

sealed class TradeDecision {
    data class Blocked(val reason: String) : TradeDecision()
    data class Eligible(val maxLossBudgetUsd: Double, val maxPositionNotionalUsd: Double) : TradeDecision()
}

/**
 * Conservative local preflight calculation. This is not an order placer and
 * does not guarantee that a stop will fill at its trigger price.
 */
object TradeRiskGate {
    fun evaluate(policy: AutomationPolicy, p: TradePreflight): TradeDecision {
        if (policy.requestedMode != TradingMode.LIVE)
            return TradeDecision.Blocked("Live mode is not selected.")
        if (!p.signalConfirmed) return TradeDecision.Blocked("No confirmed signal.")
        if (!p.candleClosed) return TradeDecision.Blocked("Wait for the 5-minute candle to close.")
        if (!policy.mandatoryStopLoss || p.stopLossPrice == null)
            return TradeDecision.Blocked("A mandatory stop-loss is missing.")
        if (policy.leverage != 1) return TradeDecision.Blocked("Only 1x exposure is allowed.")
        if (p.entryPrice <= 0 || p.stopLossPrice <= 0 || p.entryPrice == p.stopLossPrice)
            return TradeDecision.Blocked("Invalid entry or stop-loss price.")
        if (p.openPositions >= policy.maxOpenPositions)
            return TradeDecision.Blocked("Maximum open-position limit reached.")
        if (p.tradesToday >= policy.maxTradesPerDay)
            return TradeDecision.Blocked("Daily trade limit reached.")
        if (p.consecutiveLosses >= policy.consecutiveLossLimit)
            return TradeDecision.Blocked("Cooldown required after consecutive losses.")
        if (p.dailyRealizedLossUsd >= policy.maxDailyLossUsd)
            return TradeDecision.Blocked("Daily loss limit reached.")
        if (p.estimatedFeesUsd < 0 || p.estimatedSlippageUsd < 0)
            return TradeDecision.Blocked("Invalid fee or slippage estimate.")

        val stopFraction = kotlin.math.abs(p.entryPrice - p.stopLossPrice) / p.entryPrice
        if (stopFraction <= 0) return TradeDecision.Blocked("Invalid stop distance.")

        // Reserve part of the $0.10 loss budget for fees and slippage.
        val totalRiskBudget = policy.maxRiskUsd
        val priceRiskBudget = totalRiskBudget - p.estimatedFeesUsd - p.estimatedSlippageUsd
        if (priceRiskBudget <= 0) return TradeDecision.Blocked("Fees/slippage consume the risk budget.")

        val maxNotional = priceRiskBudget / stopFraction
        if (maxNotional > policy.startingCapitalUsd)
            return TradeDecision.Eligible(totalRiskBudget, policy.startingCapitalUsd)
        if (maxNotional < p.exchangeMinNotionalUsd)
            return TradeDecision.Blocked("Exchange minimum order size exceeds the risk-based position size.")
        return TradeDecision.Eligible(totalRiskBudget, maxNotional)
    }
}

/**
 * Live execution remains deliberately unavailable in this Android starter.
 * Connect this interface only to a separately secured backend after testnet,
 * stop-order recovery, reconciliation and kill-switch tests pass.
 */
interface SecureExecutionService {
    suspend fun submitSpotOrder(/* validated intent only */): String
}
